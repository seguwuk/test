import { Component } from '@angular/core';

@Component({
  selector: 'app-porta3',
  templateUrl: './porta3.component.html',
  styleUrls: ['./porta3.component.css']
})
export class Porta3Component {

}
