import { Component } from '@angular/core';

@Component({
  selector: 'app-porta2',
  templateUrl: './porta2.component.html',
  styleUrls: ['./porta2.component.css']
})
export class Porta2Component {

}
